//By Mustfa

#import "DLGMemUIView.h"
#import "Offset.h"
#import "DLGMemUIViewCell.h"


#import <AdSupport/AdSupport.h>
#import <CommonCrypto/CommonCrypto.h>



#define MaxResultCount  500
@interface DLGMemUIView () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, DLGMemUIViewCellDelegate> {
    search_result_t *chainArray;
}




@property (nonatomic) UIButton *btnConsole;
@property (nonatomic) UITapGestureRecognizer *tapGesture;
@property (nonatomic) CGRect rcCollapsedFrame;
@property (nonatomic) CGRect rcExpandedFrame;
@property (nonatomic) UIView *vContent;
@property (nonatomic) UILabel *lblType;
@property (nonatomic) UIView *vSearch;
@property (nonatomic) UITextField *tfValue;
@property (nonatomic) UIButton *btnSearch;
@property (nonatomic) UIView *vOption;
@property (nonatomic) UISegmentedControl *scComparison;
@property (nonatomic) UISegmentedControl *scUValueType;
@property (nonatomic) UISegmentedControl *scSValueType;
@property (nonatomic) UIView *vResult;
@property (nonatomic) UILabel *lblResult;
@property (nonatomic) UITableView *tvResult;
@property (nonatomic) UIView *vMore;
@property (nonatomic) UIButton *btnReset;
@property (nonatomic) UIButton *btnMemory;
@property (nonatomic) UIButton *btnRefresh;
@property (nonatomic) UIView *vMemoryContent;
@property (nonatomic) UIView *vMemory;
@property (nonatomic) UITextField *tfMemorySize;
@property (nonatomic) UITextField *tfMemory;
@property (nonatomic) UIButton *btnSearchMemory;
@property (nonatomic) UITextView *tvMemory;
@property (nonatomic) UIButton *btnBackFromMemory;
@property (nonatomic, weak) UIView *vShowingContent;
@property (nonatomic) NSLayoutConstraint *lcUValueTypeTopMargin;
@property (nonatomic) BOOL isUnsignedValueType;
@property (nonatomic) NSInteger selectedValueTypeIndex;
@property (nonatomic) NSInteger selectedComparisonIndex;
@property (nonatomic, weak) UITextField *tfFocused;
@property (nonatomic) DLGMemValueKind dlgmemvalueKind;
@property (nonatomic) BOOL tianxianareyouok;
@end



@implementation DLGMemUIView
+ (instancetype)instance
{
    static DLGMemUIView *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[DLGMemUIView alloc] init];
    });
    return _instance;
}
- (instancetype)init {
    self = [super init];
    if (self) {






UIWindow *mainWindow; 
mainWindow = [UIApplication sharedApplication].keyWindow;

menu1 = [[UIButton alloc]init];
        [menu1 addTarget:self action:@selector(wasDragged:withEvent:) 
    forControlEvents:UIControlEventTouchDragInside];
[mainWindow addSubview:menu1];


end = [[UIButton alloc]init];
[menu1 addSubview:end];


h = [[UIButton alloc]init];
[menu1 addSubview:h];



aa = [[UISwitch alloc]init];
[menu1 addSubview:aa];

bb = [[UISwitch alloc]init];
[menu1 addSubview:bb];


cc = [[UISwitch alloc]init];
[menu1 addSubview:cc];


dd = [[UISwitch alloc]init];
[menu1 addSubview:dd];

ee = [[UISwitch alloc]init];
[menu1 addSubview:ee];

ff = [[UISwitch alloc]init];
[menu1 addSubview:ff];

gg = [[UISwitch alloc]init];
[menu1 addSubview:gg];

hh = [[UISwitch alloc]init];
[menu1 addSubview:hh];



ahmed = [[UISwitch alloc]init];
[menu1 addSubview:ahmed];


ahmed1 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed1];


ahmed2 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed2];


ahmed3 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed3];

ahmed4 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed4];

ahmed5 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed5];

ahmed6 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed6];

ahmed7 = [[UISwitch alloc]init];
[menu1 addSubview:ahmed7];



zx = [[UILabel alloc]init];
[menu1 addSubview:zx];

zc = [[UILabel alloc]init];
[menu1 addSubview:zc];

zv = [[UILabel alloc]init];
[menu1 addSubview:zv];

zb = [[UILabel alloc]init];
[menu1 addSubview:zb];

zn = [[UILabel alloc]init];
[menu1 addSubview:zn];

zm = [[UILabel alloc]init];
[menu1 addSubview:zm];


za = [[UILabel alloc]init];
[menu1 addSubview:za];

zs = [[UILabel alloc]init];
[menu1 addSubview:zs];


zd = [[UILabel alloc]init];
[menu1 addSubview:zd];

zf = [[UILabel alloc]init];
[menu1 addSubview:zf];


zg = [[UILabel alloc]init];
[menu1 addSubview:zg];


zh = [[UILabel alloc]init];
[menu1 addSubview:zh];

zj = [[UILabel alloc]init];
[menu1 addSubview:zj];


zk = [[UILabel alloc]init];
[menu1 addSubview:zk];

zl = [[UILabel alloc]init];
[menu1 addSubview:zl];

zq = [[UILabel alloc]init];
[menu1 addSubview:zq];


salman =[[UILabel alloc]init];
[menu1 addSubview:salman];

lin = [[UIButton alloc]init];
[menu1 addSubview:lin];


end = [[UIButton alloc]init];
[menu1 addSubview:end];


UIButton *myButton = [UIButton buttonWithType:UIButtonTypeSystem];

[menu1 addSubview:myButton];




        [self initViews];
    }
    return self;
}
- (void)initViews {



f1 = [[UIButton alloc]init];

f1.frame = CGRectMake(5,0,45,30);
f1.translatesAutoresizingMaskIntoConstraints = NO;
[f1 setTitle:@"ON" forState:UIControlStateNormal];
[f1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
f1.backgroundColor = [UIColor blackColor];
f1.layer.shadowOpacity = 5; 
f1.layer.shadowColor = [UIColor redColor].CGColor; 
f1.layer.shadowRadius = 20;
f1.layer.cornerRadius = 10;
[f1 addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];
[self addSubview:f1];


 


[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(DLG) userInfo:nil repeats:YES];

UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeMenu)];

        tap3.numberOfTapsRequired = 2;
        tap3.numberOfTouchesRequired = 1;
        [menu1 addGestureRecognizer:tap3];



}

- (void)DLG {

[aa addTarget:self                action:@selector(switchIsChanged:)                forControlEvents:UIControlEventValueChanged];



[ff addTarget:self                action:@selector(switchIsChanged1:)                forControlEvents:UIControlEventValueChanged];

[bb addTarget:self                action:@selector(switchIsChanged2:)                forControlEvents:UIControlEventValueChanged];


[cc addTarget:self                action:@selector(switchIsChanged4:)                forControlEvents:UIControlEventValueChanged];


}



- (void)IFAKEDYUO {

mustfa(0x1000EF484, 0x0C0035FD6); 
  mustfa(0x101445A10, 0x0C0035FD6);
  mustfa(0x1014E0C84, 0x0C0035FD6);
  mustfa(0x10000F73C, 0x0C0035FD6);
  mustfa(0x10004FE84, 0x0C0035FD6);
 mustfa(0x1001CAB24, 0x0C0035FD6);
  mustfa(0x10003B7C0, 0x0C0035FD6);
  mustfa(0x101301ADC, 0x0C0035FD6);
  mustfa(0x1013953E8, 0x0C0035FD6);
  mustfa(0x1013775B4, 0x0C0035FD6);
  mustfa(0x10136F27C, 0x0C0035FD6);
  mustfa(0x1013A1D14, 0x0C0035FD6);
  mustfa(0x1026727DC, 0x0C0035FD6);
  mustfa(0x107C8450E, 0x0C0035FD6); 
  mustfa(0x107A9D4FD, 0x0C0035FD6); 
  mustfa(0x107A9D431, 0x0C0035FD6); 
  mustfa(0x1053916A0, 0x0C0035FD6);   
  mustfa(0x105139984, 0x0C0035FD6); 
  mustfa(0x1051C9E8F, 0x0C0035FD6); 
  mustfa(0x100299000, 0x0C0035FD6); 
  mustfa(0x100298FB0, 0x0C0035FD6); 
  mustfa(0x100298E08, 0x0C0035FD6); 
  mustfa(0x100298C04, 0x0C0035FD6); 
  mustfa(0x10512F908, 0x0C0035FD6);
  mustfa(0x1052028F2, 0x0C0035FD6);
  mustfa(0x10520292B, 0x0C0035FD6);


  mustfa(0x1050DCF41, 0x0C0035FD6); 
  mustfa(0x1050DCF31, 0x0C0035FD6); 
  mustfa(0x1050DCCE7, 0x0C0035FD6); 
  mustfa(0x1050DBF53, 0x0C0035FD6); 
  mustfa(0x1050DB637, 0x0C0035FD6); 
  mustfa(0x1050DB5FA, 0x0C0035FD6); 
  mustfa(0x1050DBF53, 0x0C0035FD6); 
  mustfa(0x1053755CC, 0x0C0035FD6); 
  mustfa(0x105375362, 0x0C0035FD6); 
  mustfa(0x105375564, 0x0C0035FD6); 
  mustfa(0x1053750B3, 0x0C0035FD6); 
  mustfa(0x10537514A, 0x0C0035FD6); 
 mustfa(0x105375057, 0x0C0035FD6); 
  mustfa(0x105374D38, 0x0C0035FD6); 
  mustfa(0x10537512D, 0x0C0035FD6); 
  mustfa(0x105374C75, 0x0C0035FD6); 
 mustfa(0x105374B98, 0x0C0035FD6); 
  mustfa(0x1051CAB65, 0x0C0035FD6); 
  mustfa(0x1051CB32A, 0x0C0035FD6); 
  mustfa(0x1051CAC59, 0x0C0035FD6); 
  mustfa(0x1051CAA54, 0x0C0035FD6); 
  mustfa(0x1051CAA60, 0x0C0035FD6); 
  mustfa(0x1051CC311, 0x0C0035FD6); 
  mustfa(0x1051CBED9, 0x0C0035FD6); 
  mustfa(0x1053B8CEF, 0x0C0035FD6); 
  mustfa(0x1052F280C, 0x0C0035FD6); 
  mustfa(0x1031CC6CC, 0x0C0035FD6); 
  mustfa(0x1031CC690, 0x0C0035FD6); 
  mustfa(0x1031CC65C, 0x0C0035FD6); 
  mustfa(0x1031CC618, 0x0C0035FD6); 
  mustfa(0x1031CC5F0, 0x0C0035FD6); 
 mustfa(0x1031CC534, 0x0C0035FD6); 
  mustfa(0x1031CC3D4, 0x0C0035FD6); 
  mustfa(0x1031CC278, 0x0C0035FD6); 
 mustfa(0x1013CC1F8, 0x0C0035FD6); 
  mustfa(0x10001123C, 0x0C0035FD6); 
 mustfa(0x100010ED4, 0x0C0035FD6); 
  mustfa(0x100010BEC, 0x0C0035FD6); 
  mustfa(0x1000085A8, 0x0C0035FD6); 
  mustfa(0x100008598, 0x0C0035FD6); 
  mustfa(0x100008B40, 0x0C0035FD6); 
  mustfa(0x10000858C, 0x0C0035FD6); 
  mustfa(0x1000084FC, 0x0C0035FD6); 
  mustfa(0x1000081F8, 0x0C0035FD6); 
  mustfa(0x1000081CC, 0x0C0035FD6); 
  mustfa(0x1031CC7E4, 0x0C0035FD6); 
  mustfa(0x1031CC760, 0x0C0035FD6); 
  mustfa(0x1031CC710, 0x0C0035FD6); 
  mustfa(0x100123394, 0x0C0035FD6); 
 mustfa(0x1001233CC, 0x0C0035FD6); 
 mustfa(0x100123348, 0x0C0035FD6); 
  mustfa(0x100123314, 0x0C0035FD6); 
  mustfa(0x100122FFC, 0x0C0035FD6); 
  mustfa(0x1001230AC, 0x0C0035FD6); 
  mustfa(0x100123308, 0x0C0035FD6); 
  mustfa(0x100122FBC, 0x0C0035FD6); 
  mustfa(0x100120930, 0x0C0035FD6); 
mustfa(0x1001222E4, 0x0C0035FD6); 
mustfa(0x100122E84, 0x0C0035FD6); 
 mustfa(0x100122F28, 0x0C0035FD6); 
 mustfa(0x100120520, 0x0C0035FD6); 
 mustfa(0x1001202FC, 0x0C0035FD6); 
mustfa(0x10011F01C, 0x0C0035FD6); 
mustfa(0x1001200DC, 0x0C0035FD6); 
  mustfa(0x10011B03C, 0x0C0035FD6); 
mustfa(0x10011AC7C, 0x0C0035FD6); 
mustfa(0x10011ACCC, 0x0C0035FD6); 
mustfa(0x10011AB20, 0x0C0035FD6); 
mustfa(0x10011AC60, 0x0C0035FD6); 
  mustfa(0x10011A780, 0x0C0035FD6); 
 mustfa(0x10011AA2C, 0x0C0035FD6); 
 mustfa(0x10011AA78, 0x0C0035FD6); 
mustfa(0x10011A64C, 0x0C0035FD6); 
mustfa(0x10011A718, 0x0C0035FD6); 
  mustfa(0x100119984, 0x0C0035FD6); 
mustfa(0x100119944, 0x0C0035FD6); 
mustfa(0x100833CA0, 0x0C0035FD6); 
  mustfa(0x1050A9522, 0x0C0035FD6); 
  mustfa(0x1050A952D, 0x0C0035FD6); 
  mustfa(0x103946440, 0x0C0035FD6); 
  mustfa(0x1011E9F64, 0x0C0035FD6); 



}



-(void)openMenu {






UIButton *myButton = [UIButton buttonWithType:UIButtonTypeSystem];
    myButton.frame = CGRectMake(12.65, 44.65, 35.7, 21.7);
    [myButton sizeToFit];
    [myButton setTitle:@"Hello_World" forState:UIControlStateNormal];
  






[f1 setTitle:@"OFF" forState:UIControlStateNormal];
[f1 addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];


UIColor *switchColor = [UIColor redColor];

UIColor *TitleColor = [UIColor whiteColor];



NSString *feature1 = @"انتينا";
NSString *feature2 = @"مجك";
NSString *feature3 = @"سايت سكوب";
NSString *feature4 = @"ثبات";
NSString *feature5 = @"ايمبوت";
NSString *feature6 = @"فلاش";
NSString *feature7 = @"زحف سريع";
NSString *feature8 = @"طلقه سريعه";
NSString *feature9 = @"لون لاعب";
NSString *feature10 = @"علامه تصويب +";
NSString *feature11 = @"تكبير سكوب 💯";
NSString *feature12 = @"اخفاء عشب";
NSString *feature13 = @"Ggg";
NSString *feature14 = @"Ggg";
NSString *feature15 = @"Ggg";
NSString *feature16 = @"Ggg";












aa.frame = CGRectMake(12.65, 44.65, 35.7, 21.7);
aa.transform = CGAffineTransformMakeScale(0.7, 0.7);


menu1.frame = CGRectMake(150, 60, 400, 230);
menu1.backgroundColor=[[UIColor alloc] initWithPatternImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://zoro511.lovestoblog.com/mustfadev.png"]]]];

menu1.layer.cornerRadius = 5;   
menu1.layer.shadowOpacity = 5;
menu1.layer.shadowColor = [UIColor whiteColor].CGColor;
menu1.layer.shadowRadius = 20;
menu1.layer.borderWidth = 2.0f;
menu1.layer.borderColor =  [UIColor whiteColor].CGColor;


qq.frame = CGRectMake(90000, 90000, 0, 0);
bb.frame = CGRectMake(12.65, 104.65, 35.7, 21.7); 
cc.frame = CGRectMake(12.65, 134.65, 35.7, 21.7); 
dd.frame = CGRectMake(12.65, 164.56, 35.7, 21.7); 
ee.frame = CGRectMake(12.65, 194.65, 35.7, 21.7); 

ff.frame = CGRectMake(12.65, 74.65, 35.7, 21.7); 

//2
gg.frame = CGRectMake(348.15, 44.65, 35.7, 21.7); 
hh.frame = CGRectMake(348.15, 74.65, 35.7, 21.7); 
ahmed.frame = CGRectMake(348.15, 104.65, 35.7, 21.7); 
ahmed1.frame = CGRectMake(348.15, 134.65, 35.7, 21.7); 
ahmed2.frame = CGRectMake(348.15, 164.65, 35.7, 21.7); 
ahmed3.frame = CGRectMake(348.15, 194.65, 35.7, 21.7); 


ahmed4.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed5.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed6.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed7.frame = CGRectMake(90000, 90000, 0, 0);

 
aa.onTintColor = switchColor;
bb.onTintColor = switchColor;
cc.onTintColor = switchColor;
dd.onTintColor = switchColor;
ee.onTintColor = switchColor;
ff.onTintColor = switchColor;
gg.onTintColor = switchColor;
hh.onTintColor = switchColor;
ahmed.onTintColor = switchColor;
ahmed1.onTintColor = switchColor;
ahmed2.onTintColor = switchColor;
ahmed3.onTintColor = switchColor;
ahmed4.onTintColor = switchColor;
ahmed5.onTintColor = switchColor;
ahmed6.onTintColor = switchColor;
ahmed7.onTintColor = switchColor;
bb.transform = CGAffineTransformMakeScale(0.7, 0.7);
cc.transform = CGAffineTransformMakeScale(0.7, 0.7);
dd.transform = CGAffineTransformMakeScale(0.7, 0.7);
ee.transform = CGAffineTransformMakeScale(0.7, 0.7);
ff.transform = CGAffineTransformMakeScale(0.7, 0.7);
gg.transform = CGAffineTransformMakeScale(0.7, 0.7);
hh.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed1.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed2.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed3.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed4.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed5.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed6.transform = CGAffineTransformMakeScale(0.7, 0.7);
ahmed7.transform = CGAffineTransformMakeScale(0.7, 0.7);


zx.frame = CGRectMake(111, 48, 100, 13);
zx.text = feature1;
zc.frame = CGRectMake(111, 78, 100, 13);
zc.text = feature2;
zv.frame = CGRectMake(111, 108, 100, 13);
zv.text = feature3;
zb.frame = CGRectMake(111, 138, 100, 13);
zb.text = feature4;
zn.frame = CGRectMake(111, 168, 100, 13);
zn.text = feature5;
zm.frame = CGRectMake(111, 198, 100, 13);
zm.text = feature6;

za.frame = CGRectMake(212, 48, 100, 13);
za.text = feature7;
zs.frame = CGRectMake(212, 78, 100, 13);
zs.text = feature8;
zd.frame = CGRectMake(212, 108, 100, 13);
zd.text = feature9;
zf.frame = CGRectMake(212, 138, 100, 13);
zf.text = feature10;
zg.frame = CGRectMake(212, 168, 100, 13);
zg.text = feature11;
zh.frame = CGRectMake(212, 198, 100, 13);
zh.text = feature12;

zj.frame = CGRectMake(0, 0, 0, 0);
zj.text = feature13;
zk.frame = CGRectMake(0, 0, 0, 0);
zk.text = feature14;
zl.frame = CGRectMake(0, 0, 0, 0);
zl.text = feature15;
zq.frame = CGRectMake(0, 0, 0, 0);
zq.text = feature16;
zx.font = [UIFont fontWithName:@"papyrus" size:12];
zc.font = [UIFont fontWithName:@"papyrus" size:12];
zv.font = [UIFont fontWithName:@"papyrus" size:12];
zb.font = [UIFont fontWithName:@"papyrus" size:12];
zn.font = [UIFont fontWithName:@"papyrus" size:12];
zm.font = [UIFont fontWithName:@"papyrus" size:12];
za.font = [UIFont fontWithName:@"papyrus" size:12];
zs.font = [UIFont fontWithName:@"papyrus" size:12];
zd.font = [UIFont fontWithName:@"papyrus" size:12];
zf.font = [UIFont fontWithName:@"papyrus" size:12];
zg.font = [UIFont fontWithName:@"papyrus" size:12];
zh.font = [UIFont fontWithName:@"papyrus" size:12];
zj.font = [UIFont fontWithName:@"papyrus" size:12];
zk.font = [UIFont fontWithName:@"papyrus" size:12];
zl.font = [UIFont fontWithName:@"papyrus" size:12];
zq.font = [UIFont fontWithName:@"papyrus" size:12];
zx.textColor = TitleColor;
zc.textColor = TitleColor;
zv.textColor = TitleColor;
zb.textColor = TitleColor;
zn.textColor = TitleColor;
zm.textColor = TitleColor;
zq.textColor = TitleColor;
zf.textColor = TitleColor;
za.textColor = TitleColor;
zd.textColor = TitleColor;
zs.textColor = TitleColor;
zh.textColor = TitleColor;
zg.textColor = TitleColor;
zj.textColor = TitleColor;
zk.textColor = TitleColor;
zl.textColor = TitleColor;














 
UIDevice *myDevice = [UIDevice currentDevice];    
[myDevice setBatteryMonitoringEnabled:YES];

double batLeft = (float)[myDevice batteryLevel] * 100;
NSLog(@"%.f", batLeft);   

NSString *levelLabel = [NSString stringWithFormat:@"Ez. | %.f%%⚡️", batLeft];    

salman.frame = CGRectMake(95,2,167,40);
salman.text = levelLabel;

[UIView transitionWithView:salman
                          duration:1.0
                          

options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{ 

    salman.textColor = [UIColor redColor];


    salman.frame = CGRectMake(95,2,167,40);


} completion:^(BOOL finished) {
}];

salman.textColor =[UIColor whiteColor];





lin.frame = CGRectMake(40,35,320,3);
lin.backgroundColor = [UIColor whiteColor];









}



-(void)closeMenu {


[f1 setTitle:@"ON" forState:UIControlStateNormal];

[f1 addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];





menu1.frame = CGRectMake(0, 0, 0, 0);
h.frame = CGRectMake(90000, 90000, 0, 0);
qq.frame = CGRectMake(90000, 90000, 0, 0); 
aa.frame = CGRectMake(90000, 90000, 0, 0); 
bb.frame = CGRectMake(90000, 90000, 0, 0); 
cc.frame = CGRectMake(90000, 90000, 0, 0); 
dd.frame = CGRectMake(90000, 90000, 0, 0); 
ee.frame = CGRectMake(90000, 90000, 0, 0); 
ff.frame = CGRectMake(90000, 90000, 0, 0); 
gg.frame = CGRectMake(90000, 90000, 0, 0); 
hh.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed1.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed2.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed3.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed4.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed5.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed6.frame = CGRectMake(90000, 90000, 0, 0); 
ahmed7.frame = CGRectMake(90000, 90000, 0, 0); 
zx.frame = CGRectMake(0, 0, 0, 0); 
zc.frame = CGRectMake(0, 0, 0, 0); 
zv.frame = CGRectMake(0, 0, 0, 0); 
zb.frame = CGRectMake(0, 0, 0, 0); 
zn.frame = CGRectMake(0, 0, 0, 0); 
zm.frame = CGRectMake(0, 0, 0, 0); 
za.frame = CGRectMake(0, 0, 0, 0); 
zs.frame = CGRectMake(0, 0, 0, 0); 
zd.frame = CGRectMake(0, 0, 0, 0); 
zf.frame = CGRectMake(0, 0, 0, 0); 
zg.frame = CGRectMake(0, 0, 0, 0); 
zh.frame = CGRectMake(0, 0, 0, 0); 
zj.frame = CGRectMake(0, 0, 0, 0); 
zk.frame = CGRectMake(0, 0, 0, 0); 
zl.frame = CGRectMake(0, 0, 0, 0); 
zq.frame = CGRectMake(0, 0, 0, 0); 
end.frame = CGRectMake(0, 0, 0, 0);


salman.frame = CGRectMake(0,0,0,0);

}


- (void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}



- (void)collapse {
    _shouldNotBeDragged = NO;
    CGRect frame = self.rcExpandedFrame;
    frame.origin = self.frame.origin;
    self.rcExpandedFrame = frame;
    self.layer.cornerRadius = CGRectGetWidth(self.rcCollapsedFrame) / 2;
    self.vShowingContent.hidden = YES;
    [self.tfFocused resignFirstResponder];
    [self removeGesture];
    [UIView animateWithDuration:0.2f
                          delay:0.0f
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         self.frame = self.rcCollapsedFrame;
                         self.alpha = DLG_DEBUG_CONSOLE_VIEW_MIN_ALPHA;
                     }
                     completion:^(BOOL finished) {
                         self.frame = self.rcCollapsedFrame;
                         self.alpha = DLG_DEBUG_CONSOLE_VIEW_MIN_ALPHA;
                         self->_expanded = NO;
                     }];
}


#pragma mark - Gesture
- (void)handleGesture:(UITapGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateEnded) {
        CGPoint pt = [sender locationInView:self.window];
        CGRect frameInScreen = self.tfValue.frame;
        frameInScreen.origin.x += CGRectGetMinX(self.frame);
        frameInScreen.origin.y += CGRectGetMinY(self.frame);
        if (CGRectContainsPoint(frameInScreen, pt)) {
            if ([self.tfValue canBecomeFirstResponder]) {
                [self.tfValue becomeFirstResponder];
            }
        } else {
        }
    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.tfValue) {
        if (textField.returnKeyType == UIReturnKeySearch) {
            [self onSearchTapped:nil];
        }
    } else if (textField == self.tfMemory) {
        if (textField.returnKeyType == UIReturnKeySearch) {
            [self onSearchMemoryTapped:nil];
        }
    } else if (textField == self.tfMemorySize) {
        if (textField.returnKeyType == UIReturnKeyNext) {
            [self.tfMemory becomeFirstResponder];
        }
    } else {
        [textField resignFirstResponder];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tfFocused = textField;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.chainCount > MaxResultCount) return 0;
    return self.chainCount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return DLGMemUIViewCellHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DLGMemUIViewCell *cell = [tableView dequeueReusableCellWithIdentifier:DLGMemUIViewCellID forIndexPath:indexPath];
    cell.delegate = self;
    cell.textFieldDelegate = self;
    
    NSInteger index = indexPath.row;
    search_result_t result = chainArray[index];
    NSString *address = [NSString stringWithFormat:@"%llX", result->address];
    NSString *value = [self valueStringFromResult:result];
    cell.address = address;
    cell.value = value;
    cell.modifying = NO;
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger index = indexPath.row;
    search_result_t result = chainArray[index];
    NSString *address = [NSString stringWithFormat:@"%llX", result->address];
    [self showMemory:address];
}

#pragma mark - DLGMemUIViewCellDelegate
- (void)DLGMemUIViewCellModify:(NSString *)address value:(NSString *)value {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
        DLGMemValueType type = [self currentValueType];
        [self.delegate DLGMemUIModifyValue:value address:address type:type];
    }
}

- (void)DLGMemUIViewCellViewMemory:(NSString *)address {
    [self showMemory:address];
}

#pragma mark - Utils
- (NSString *)valueStringFromResult:(search_result_t)result {
    NSString *value = nil;
    int type = result->type;
    if (type == SearchResultValueTypeUInt8) {
        uint8_t v = *(uint8_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt8) {
        int8_t v = *(int8_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt16) {
        uint16_t v = *(uint16_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt16) {
        int16_t v = *(int16_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt32) {
        uint32_t v = *(uint32_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt32) {
        int32_t v = *(int32_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt64) {
        uint64_t v = *(uint64_t *)(result->value);
        value = [NSString stringWithFormat:@"%llu", v];
    } else if (type == SearchResultValueTypeSInt64) {
        int64_t v = *(int64_t *)(result->value);
        value = [NSString stringWithFormat:@"%lld", v];
    } else if (type == SearchResultValueTypeFloat) {
        float v = *(float *)(result->value);
        value = [NSString stringWithFormat:@"%f", v];
    } else if (type == SearchResultValueTypeDouble) {
        double v = *(double *)(result->value);
        value = [NSString stringWithFormat:@"%f", v];
    } else {
        NSMutableString *ms = [NSMutableString string];
        char *v = (char *)(result->value);
        for (int i = 0; i < result->size; ++i) {
            printf("%02X ", v[i]);
            [ms appendFormat:@"%02X ", v[i]];
        }
        value = ms;
    }
    return value;
}

- (DLGMemValueType)currentValueType {
    DLGMemValueType type = DLGMemValueTypeSignedInt;
    switch (self.selectedValueTypeIndex) {
        case 0: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedByte : DLGMemValueTypeSignedByte; break;
        case 1: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedShort : DLGMemValueTypeSignedShort; break;
        case 2: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedInt : DLGMemValueTypeSignedInt; break;
        case 3: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedLong : DLGMemValueTypeSignedLong; break;
        case 4: type = self.isUnsignedValueType ? DLGMemValueTypeFloat : DLGMemValueTypeDouble; break;
    }
    return type;
}

- (DLGMemComparison)currentComparison {
    DLGMemComparison comparison = DLGMemComparisonEQ;
    switch (self.selectedComparisonIndex) {
        case 0: comparison = DLGMemComparisonLT; break;
        case 1: comparison = DLGMemComparisonLE; break;
        case 2: comparison = DLGMemComparisonEQ; break;
        case 3: comparison = DLGMemComparisonGE; break;
        case 4: comparison = DLGMemComparisonGT; break;
    }
    return comparison;
}



#pragma mark - Gesture
- (void)addGesture {
    if (self.tapGesture != nil) return;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    tap.numberOfTapsRequired = 0;
    tap.numberOfTouchesRequired = 0;
    [self addGestureRecognizer:tap];
    
    self.tapGesture = tap;
}

- (void)removeGesture {
    if (self.tapGesture == nil) { return; }
    
    [self removeGestureRecognizer:self.tapGesture];
    self.tapGesture = nil;
}

#pragma mark - Events
- (void)onSearchTapped:(id)sender {
    [self.tfValue resignFirstResponder];
    if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
        NSString *value = self.tfValue.text;
        if (value.length == 0) return;
        DLGMemValueType type = [self currentValueType];
        DLGMemComparison comparison = [self currentComparison];
        switch (self.selectedComparisonIndex) {
            case 0: comparison = DLGMemComparisonLT; break;
            case 1: comparison = DLGMemComparisonLE; break;
            case 2: comparison = DLGMemComparisonEQ; break;
            case 3: comparison = DLGMemComparisonGE; break;
            case 4: comparison = DLGMemComparisonGT; break;
        }
        [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
    }
}

- (void)onResetTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIReset)]) {
        [self.delegate DLGMemUIReset];
    }
}

- (void)onRefreshTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIRefresh)]) {
        [self.delegate DLGMemUIRefresh];
    }
}

- (void)onMemoryTapped:(id)sender {
    if (self.tvMemory.text.length == 0) {
        [self showMemory:self.tfMemory.text];
    } else {
        [self showMemory];
    }
}

- (void)onComparisonChanged:(id)sender {
    self.selectedComparisonIndex = self.scComparison.selectedSegmentIndex;
}


- (void)onSearchMemoryTapped:(id)sender {
    [self.tfMemory resignFirstResponder];
    [self.tfMemorySize resignFirstResponder];
    NSString *address = self.tfMemory.text;
    NSString *size = self.tfMemorySize.text;
    if (address.length == 0) return;
    if ([self.delegate respondsToSelector:@selector(DLGMemUIMemory:size:)]) {
        NSString *memory = [self.delegate DLGMemUIMemory:address size:size];
        self.tvMemory.text = memory;
    }
}

- (void)onBackFromMemoryTapped:(id)sender {
    self.vMemoryContent.hidden = YES;
    self.vContent.hidden = NO;
    self.vShowingContent = self.vContent;
    self.tvMemory.text = @"";
}

- (void)showMemory {
    self.vContent.hidden = YES;
    self.vMemoryContent.hidden = NO;
    self.vShowingContent = self.vMemoryContent;
}

- (void)showMemory:(NSString *)address {
    [self showMemory];
    self.tfMemory.text = address;
    self.tvMemory.text = @"";
    [self onSearchMemoryTapped:nil];
}


#pragma mark - Expand & Collapse


- (void)setChain:(search_result_chain_t)chain 
{    _chain = chain;    if (chainArray) 
{     free(chainArray);        chainArray = NULL;                                  }
    if (self.chainCount > 0 && self.chainCount <= MaxResultCount) 
{        chainArray = malloc(sizeof(search_result_t) * self.chainCount);
        search_result_chain_t c = chain;
        int i = 0; while (i < self.chainCount) 
{   if (c->result) chainArray[i++] = c->result; c = c->next;  if (c == NULL) break;}
    if (i < self.chainCount) self.chainCount = i;                                  }
    if (chainArray==NULL) 
{        return;                                                                   }

   

else if (self.dlgmemvalueKind==DLGMemValueTypetianxian2)//天线1
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"5292894979034305258" address:address type:type];
            }
        }
    }
    else if (self.dlgmemvalueKind==DLGMemValueTypetianxian3)//天线1
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"480493" address:address type:type];
            }
        }
    }






else if (self.dlgmemvalueKind==DLGMemValueTypechuchao11)//
        {
            for (int index=0; index<self.chainCount; index++)
            {
                search_result_t result = chainArray[index];
                NSString *address = [NSString stringWithFormat:@"%llX", result->address];
                if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                    DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                    [self.delegate DLGMemUIModifyValue:@"5302743970099999910" address:address type:type];
                }
            }
        }





   
    if ([self.delegate respondsToSelector:@selector(DLGMemUIReset)]) {
        [self.delegate DLGMemUIReset];
    }
}

- (void)switchIsChanged:(UISwitch *)feature1 {
    


    if ([feature1 isOn]) {



if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian2;
                NSString *value = @"4575657224676430570";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }


            if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian3;
                NSString *value = @"4804934254803878643";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                });
            }



}else{

}









}





- (void)switchIsChanged1:(UISwitch *)feature2 {
    


    if ([feature2 isOn]) {





if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypechuchao11;
                NSString *value = @"4740038608910024704";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }


}else{

}









}





- (void)switchIsChanged4:(UISwitch *)feature4 {
    


    if ([feature4 isOn]) {

mustfa(0x102674DF8, 0xE003271E);

mustfa(0x102672688, 0xC0035FD6);

mustfa(0x10467C60C, 0xC0035FD6);

mustfa(0x10255BE50, 0xC0035FD6);

}else{

mustfa(0x102672688, 0xC0035FD6);

mustfa(0x102672688, 0xFF4301D1);

mustfa(0x10467C60C, 0xED33BB6D);

mustfa(0x10255BE50, 0xF657BDA9);


}









}














@end
