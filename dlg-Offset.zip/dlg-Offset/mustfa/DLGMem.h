//
//  DLGMem.h
//  memui
//
//  Created by Liu Junqi on 4/23/18.
//  Copyright © 2018 DeviLeo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DLGMem : NSObject

- (void)launchDLGMem;

@end
